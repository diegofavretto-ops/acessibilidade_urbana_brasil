# Project Charter

## Nome do projeto

Acessibilidade Urbana no Brasil

## Objetivo

Desenvolver uma aplicação em Streamlit para facilitar a visualização de dados do IBGE sobre acessibilidade e conforto do pedestre no entorno urbano.

## Escopo

Analisar dados sobre calçadas, rampas, obstáculos e arborização, organizando as informações para apresentação em tabelas e gráficos.

## Stakeholders

Gestores públicos, engenheiros, arquitetos, urbanistas, estudantes, pesquisadores e cidadãos.